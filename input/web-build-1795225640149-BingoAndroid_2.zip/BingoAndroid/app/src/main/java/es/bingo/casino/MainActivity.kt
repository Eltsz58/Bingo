package es.bingo.casino

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.*
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var game: BingoView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        game = BingoView()
        setContentView(game)
        game.post { showSetup(false) }
    }

    private fun showSetup(restarting: Boolean) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 8)
        }
        val money = EditText(this).apply {
            hint = "Recaudación (€)"
            inputType = 8194
            setText(game.collection.toString())
        }
        val names = EditText(this).apply {
            hint = "Jugadores (un nombre por línea)"
            minLines = 4
            gravity = android.view.Gravity.TOP
            setText(game.players.joinToString("\n"))
        }
        box.addView(money)
        box.addView(names)

        AlertDialog.Builder(this)
            .setTitle("Configuración de la jugada")
            .setView(box)
            .setPositiveButton("Comenzar") { _, _ ->
                game.collection = money.text.toString()
                    .replace(',', '.')
                    .toDoubleOrNull()
                    ?.coerceAtLeast(0.0) ?: 0.0

                game.players = names.text.lines()
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }

                if (restarting) game.reset()
                game.invalidate()
            }
            .setCancelable(false)
            .show()
    }

    private fun showPlayersDialog() {
        val names = EditText(this).apply {
            hint = "Un nombre por línea"
            minLines = 4
            gravity = android.view.Gravity.TOP
            setText(game.players.joinToString("\n"))
        }

        AlertDialog.Builder(this)
            .setTitle("Jugadores")
            .setView(names)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                game.players = names.text.lines()
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                game.invalidate()
            }
            .show()
    }

    private fun confirmNewGame() {
        AlertDialog.Builder(this)
            .setTitle("Nueva partida")
            .setMessage("Se borrarán las bolas extraídas y los premios anotados. ¿Continuar?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Continuar") { _, _ -> showSetup(true) }
            .show()
    }

    private fun showSimpleDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Aceptar", null)
            .show()
    }

    private fun prizeDialog(line: Boolean) {
        val amount = if (line) game.linePrize else game.bingoPrize
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 12, 40, 0)
        }
        val winner = EditText(this).apply {
            hint = "Nombre del ganador"
            if (game.players.isNotEmpty()) setText(game.players.first())
        }
        val paid = EditText(this).apply {
            hint = "Premio entregado (€)"
            inputType = 8194
            setText(String.format(Locale.US, "%.2f", amount))
        }
        box.addView(winner)
        box.addView(paid)

        AlertDialog.Builder(this)
            .setTitle(if (line) "¡LÍNEA!" else "¡BINGO!")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Aceptar") { _, _ ->
                val name = winner.text.toString().trim()
                if (name.isNotEmpty()) {
                    val paidAmount = paid.text.toString()
                        .replace(',', '.')
                        .toDoubleOrNull() ?: amount

                    if (line) {
                        game.lineDone = true
                        game.lineWinner = name
                        game.linePaid = paidAmount
                    } else {
                        game.bingoDone = true
                        game.bingoWinner = name
                        game.bingoPaid = paidAmount
                    }

                    game.invalidate()
                    if (!line) {
                        showSimpleDialog("Fin de partida", game.summary())
                    }
                }
            }
            .show()
    }

    inner class BingoView : View(this) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rand = Random(System.nanoTime())
        private val bag = (1..90).toMutableList()
        private val drawn = mutableListOf<Int>()
        private val marked = BooleanArray(91)

        var collection = 100.0
        var players = listOf<String>()
        var lineDone = false
        var bingoDone = false
        var lineWinner = ""
        var bingoWinner = ""
        var linePaid = 0.0
        var bingoPaid = 0.0
        var paused = false

        private var current = 0
        private var phase = 0 // idle, mix, fall, zoom, hold, fly
        private var phaseAt = 0L
        private var lastDrawn = 0
        private var lastDrawAt = 0L
        private var board = RectF()

        private val gold = Color.rgb(222, 180, 83)
        private val bg = Color.rgb(10, 13, 25)
        private val colors = intArrayOf(
            0xffd62828.toInt(), 0xfff08c1e.toInt(), 0xffe6c31e.toInt(),
            0xff3caa46.toInt(), 0xff1ea0a5.toInt(), 0xff326ee0.toInt(),
            0xff8246be.toInt(), 0xffe15aa0.toInt(), 0xff82705f.toInt()
        )

        val linePrize: Double
            get() = round(collection * .20 * 100) / 100

        val bingoPrize: Double
            get() = collection - linePrize

        private val buttons = mutableListOf<Pair<RectF, String>>()

        fun reset() {
            bag.clear()
            bag.addAll(1..90)
            drawn.clear()
            for (i in marked.indices) marked[i] = false
            phase = 0
            paused = false
            lineDone = false
            bingoDone = false
            lineWinner = ""
            bingoWinner = ""
            linePaid = 0.0
            bingoPaid = 0.0
            current = 0
            lastDrawn = 0
            lastDrawAt = 0L
            invalidate()
        }

        private fun money(v: Double): String =
            NumberFormat.getCurrencyInstance(Locale("es", "ES")).format(v)

        fun summary(): String {
            val line = if (lineDone) "LÍNEA: $lineWinner (${money(linePaid)})\n"
                       else "LÍNEA: pendiente\n"
            val bingo = if (bingoDone) "BINGO: $bingoWinner (${money(bingoPaid)})\n"
                        else "BINGO: pendiente\n"
            return line + bingo + "Bolas extraídas: ${drawn.size}/90"
        }

        fun sessionReport(): String {
            return "Jugadores: ${players.size}\n" +
                "Bolas extraídas: ${drawn.size}/90\n" +
                "Recaudación: ${money(collection)}\n" +
                "Premio de línea: ${money(linePrize)}\n" +
                "Premio de bingo: ${money(bingoPrize)}\n\n" +
                summary()
        }

        fun statisticsReport(): String {
            return "Bolas extraídas: ${drawn.size}\n" +
                "Bolas restantes: ${bag.size}\n" +
                "Jugadores: ${players.size}\n" +
                "Recaudación: ${money(collection)}\n" +
                "Premio de línea: ${money(linePrize)}\n" +
                "Premio de bingo: ${money(bingoPrize)}"
        }

        private fun startDraw() {
            if (phase != 0 || paused || bingoDone || bag.isEmpty()) return
            current = bag.removeAt(rand.nextInt(bag.size))
            phase = 1
            phaseAt = System.currentTimeMillis()
            invalidate()
        }

        private fun pauseGame() {
            if (phase == 0 && !bingoDone) paused = !paused
            invalidate()
        }

        private fun doLine() {
            if (phase == 0 && drawn.isNotEmpty() && !lineDone && !bingoDone) {
                prizeDialog(true)
            }
        }

        private fun doBingo() {
            if (phase == 0 && drawn.isNotEmpty() && !bingoDone) {
                prizeDialog(false)
            }
        }

        /*
         * Distribución inferior: información a la izquierda y diez botones
         * en dos filas de cinco a la derecha. El tablero y el bombo quedan
         * completamente por encima de esta zona.
         */
        private fun buttonsLayout(w: Float, h: Float) {
            buttons.clear()
            val startX = w * .30f
            val endX = w * .975f
            val gap = w * .006f
            val bw = (endX - startX - gap * 4) / 5f
            val bh = h * .078f
            val y1 = h * .77f
            val y2 = h * .88f

            val labels = listOf(
                "Inicio Sesión",
                "Jugadores",
                "Nueva partida",
                "Sacar bola",
                "Cantar Línea",
                "Fin de Sesión",
                "Cartones",
                if (paused) "Continuar" else "Parada",
                "Estadísticas",
                "Cantar Bingo"
            )

            for (i in labels.indices) {
                val row = i / 5
                val col = i % 5
                val x = startX + col * (bw + gap)
                val y = if (row == 0) y1 else y2
                buttons.add(RectF(x, y, x + bw, y + bh) to labels[i])
            }
        }

        private fun shadeColor(color: Int, factor: Float): Int {
            return Color.rgb(
                (Color.red(color) * factor).toInt().coerceIn(0, 255),
                (Color.green(color) * factor).toInt().coerceIn(0, 255),
                (Color.blue(color) * factor).toInt().coerceIn(0, 255)
            )
        }

        private fun draw3DButton(
            canvas: Canvas,
            rect: RectF,
            label: String,
            baseColor: Int,
            enabled: Boolean,
            h: Float
        ) {
            val depth = max(3f, rect.height() * .16f)
            val face = RectF(
                rect.left,
                rect.top,
                rect.right,
                rect.bottom - depth
            )
            val radius = face.height() * .19f
            val color = if (enabled) baseColor else 0xff454b5c.toInt()

            p.shader = null
            p.style = Paint.Style.FILL
            p.color = shadeColor(color, .42f)
            canvas.drawRoundRect(rect, radius, radius, p)

            p.shader = LinearGradient(
                face.left, face.top, face.left, face.bottom,
                intArrayOf(
                    shadeColor(color, 1.35f),
                    color,
                    shadeColor(color, .70f)
                ),
                null,
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(face, radius, radius, p)
            p.shader = null

            p.shader = LinearGradient(
                face.left, face.top, face.left, face.centerY(),
                intArrayOf(0x66ffffff, 0x00ffffff),
                null,
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(face, radius, radius, p)
            p.shader = null

            p.style = Paint.Style.STROKE
            p.strokeWidth = max(1f, h * .0018f)
            p.color = if (enabled) 0xffffdf91.toInt() else 0xff687084.toInt()
            canvas.drawRoundRect(face, radius, radius, p)

            p.style = Paint.Style.FILL
            p.typeface = Typeface.create("sans-serif", Typeface.BOLD)
            p.textAlign = Paint.Align.CENTER

            var textSize = min(h * .020f, face.height() * .43f)
            p.textSize = textSize
            while (p.measureText(label) > face.width() * .90f && textSize > h * .011f) {
                textSize -= .5f
                p.textSize = textSize
            }

            val baseline = face.centerY() - (p.ascent() + p.descent()) / 2f
            p.color = 0x77000000
            canvas.drawText(label, face.centerX(), baseline + h * .002f, p)
            p.color = if (enabled) Color.WHITE else 0xffa0a5b2.toInt()
            canvas.drawText(label, face.centerX(), baseline, p)
            p.textAlign = Paint.Align.LEFT
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return

            canvas.drawColor(bg)
            val grad = LinearGradient(
                0f, 0f, w, h,
                intArrayOf(
                    0xff11172b.toInt(),
                    0xff25213b.toInt(),
                    0xff0c1020.toInt()
                ),
                null,
                Shader.TileMode.CLAMP
            )
            p.shader = grad
            canvas.drawRect(0f, 0f, w, h, p)
            p.shader = null

            // Título más arriba, sin alterar su estilo.
            p.color = gold
            p.textSize = h * .045f
            p.typeface = Typeface.create("sans-serif", Typeface.BOLD)
            canvas.drawText("BINGO  •  CASINO", w * .025f, h * .05f, p)

            // Los recuadros conservan sus dimensiones originales.
            // Únicamente se desplazan hacia arriba.
            val left = w * .025f
            val top = h * .09f
            val boardW = w * .60f
            val boardH = h * .66f
            board = RectF(left, top, left + boardW, top + boardH)

            p.color = 0xff171d31.toInt()
            canvas.drawRoundRect(board, 18f, 18f, p)

            // Se elimina únicamente el rótulo "TABLERO · 90 BOLAS".
            // La cuadrícula mantiene las proporciones originales.
            val cellW = (boardW - 24f) / 10f
            val cellH = (boardH - h * .09f) / 9f

            p.textAlign = Paint.Align.CENTER
            p.textSize = min(cellW * .42f, cellH * .55f)
            p.typeface = Typeface.create("sans-serif", Typeface.BOLD)

            for (n in 1..90) {
                val row = (n - 1) / 10
                val col = (n - 1) % 10
                val x = board.left + 12f + col * cellW
                val y = board.top + h * .065f + row * cellH
                val r = RectF(x + 2f, y + 2f, x + cellW - 2f, y + cellH - 2f)

                p.color = if (marked[n]) colors[row] else 0xff252d46.toInt()
                canvas.drawRoundRect(r, 8f, 8f, p)

                p.color = if (marked[n]) Color.WHITE else 0xffaab2c9.toInt()
                canvas.drawText(
                    n.toString(),
                    r.centerX(),
                    r.centerY() + p.textSize * .34f,
                    p
                )

                if (n == lastDrawn && System.currentTimeMillis() - lastDrawAt < 3500) {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 3f
                    p.color = gold
                    canvas.drawRoundRect(r, 8f, 8f, p)
                    p.style = Paint.Style.FILL
                }
            }
            p.textAlign = Paint.Align.LEFT

            // Recuadro del bombo: mismo ancho, alto y elementos que la versión inicial.
            val sideX = w * .66f
            val sideW = w * .315f
            p.color = 0xff202943.toInt()
            canvas.drawRoundRect(
                RectF(sideX, top, sideX + sideW, top + boardH),
                20f, 20f, p
            )

            p.color = gold
            p.textSize = h * .035f
            canvas.drawText("BOMBO", sideX + 18f, top + h * .05f, p)

            val cx = sideX + sideW * .5f
            val cy = top + boardH * .38f
            val radius = min(sideW * .32f, boardH * .25f)

            p.shader = RadialGradient(
                cx - radius * .3f,
                cy - radius * .35f,
                radius,
                intArrayOf(
                    0xff6e819e.toInt(),
                    0xff263b5e.toInt(),
                    0xff101a31.toInt()
                ),
                null,
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, radius, p)
            p.shader = null

            p.style = Paint.Style.STROKE
            p.strokeWidth = 5f
            p.color = gold
            canvas.drawCircle(cx, cy, radius, p)
            p.style = Paint.Style.FILL

            // Bolas decorativas dentro del bombo, sin cambios de tamaño.
            for (i in 0 until min(24, bag.size)) {
                val a = i * 2.399
                val rr = radius * .76f * sqrt((i + 1f) / 24f)
                p.color = colors[i % 9]
                canvas.drawCircle(
                    cx + cos(a).toFloat() * rr,
                    cy + sin(a).toFloat() * rr,
                    max(5f, radius * .075f),
                    p
                )
            }

            p.color = Color.WHITE
            p.textAlign = Paint.Align.CENTER
            p.textSize = h * .027f
            canvas.drawText("Quedan ${bag.size} bolas", cx, cy + radius + h * .045f, p)

            p.textAlign = Paint.Align.LEFT
            p.color = gold
            p.textSize = h * .03f
            canvas.drawText("ÚLTIMAS BOLAS", sideX + 18f, top + boardH * .76f, p)

            val recent = drawn.takeLast(6).asReversed()
            for (i in recent.indices) {
                val rr = h * .035f
                val bx = sideX + rr + 18f + i * (rr * 2.25f)
                val by = top + boardH * .86f
                p.color = colors[(recent[i] - 1) / 10]
                canvas.drawCircle(bx, by, rr, p)
                p.color = Color.WHITE
                p.textAlign = Paint.Align.CENTER
                p.textSize = rr * .85f
                canvas.drawText(recent[i].toString(), bx, by + rr * .3f, p)
            }
            p.textAlign = Paint.Align.LEFT

            drawAnimatedBall(canvas, w, h, cx, cy, radius)

            // Datos debajo de los paneles, en una columna propia a la izquierda.
            val infoLines = listOf(
                "Bolas extraídas: ${drawn.size}/90",
                "Recaudación: ${money(collection)}",
                "Línea 20%: ${money(linePrize)}",
                "Bingo 80%: ${money(bingoPrize)}",
                "Línea: ${if (lineDone) "$lineWinner · ${money(linePaid)}" else "pendiente"}",
                "Bingo: ${if (bingoDone) "$bingoWinner · ${money(bingoPaid)}" else "pendiente"}"
            )

            p.color = 0xffe5e9f2.toInt()
            p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            p.textAlign = Paint.Align.LEFT

            for (i in infoLines.indices) {
                p.textSize = h * .018f
                while (
                    p.measureText(infoLines[i]) > w * .265f &&
                    p.textSize > h * .010f
                ) {
                    p.textSize *= .94f
                }
                canvas.drawText(
                    infoLines[i],
                    w * .025f,
                    h * (.795f + i * .031f),
                    p
                )
            }

            // Diez botones en dos filas de cinco, con relieve 3D.
            buttonsLayout(w, h)
            val buttonColors = intArrayOf(
                0xffa7782c.toInt(), // Inicio sesión
                0xff315a86.toInt(), // Jugadores
                0xff337c59.toInt(), // Nueva partida
                0xffa46b28.toInt(), // Sacar bola
                0xff2a6880.toInt(), // Cantar línea
                0xff72572b.toInt(), // Fin de sesión
                0xff53617b.toInt(), // Cartones
                0xff8d493e.toInt(), // Parada
                0xff65558c.toInt(), // Estadísticas
                0xff39744e.toInt()  // Cantar bingo
            )

            buttons.forEachIndexed { i, pair ->
                val active = when (i) {
                    3 -> phase == 0 && !paused && !bingoDone && bag.isNotEmpty()
                    4 -> phase == 0 && drawn.isNotEmpty() && !lineDone && !bingoDone
                    7 -> phase == 0 && !bingoDone
                    9 -> phase == 0 && drawn.isNotEmpty() && !bingoDone
                    else -> true
                }
                draw3DButton(
                    canvas,
                    pair.first,
                    pair.second,
                    buttonColors[i],
                    active,
                    h
                )
            }

            p.textAlign = Paint.Align.LEFT

            if (phase != 0) {
                val elapsed = System.currentTimeMillis() - phaseAt
                val duration = longArrayOf(0, 1100, 750, 650, 1800, 750)[phase]
                if (elapsed >= duration) {
                    if (phase == 5) {
                        drawn.add(current)
                        marked[current] = true
                        lastDrawn = current
                        lastDrawAt = System.currentTimeMillis()
                        phase = 0
                    } else {
                        phase++
                        phaseAt = System.currentTimeMillis()
                    }
                }
                postInvalidateDelayed(16)
            } else if (!paused && !bingoDone) {
                postInvalidateDelayed(500)
            }

            if (paused) {
                p.color = gold
                p.textSize = h * .07f
                p.textAlign = Paint.Align.CENTER
                canvas.drawText("PARTIDA EN PAUSA", w * .5f, h * .5f, p)
                p.textAlign = Paint.Align.LEFT
            }
        }

        private fun drawAnimatedBall(
            c: Canvas,
            w: Float,
            h: Float,
            dcx: Float,
            dcy: Float,
            dr: Float
        ) {
            if (phase == 0) {
                if (drawn.isNotEmpty()) {
                    val n = drawn.last()
                    val r = min(w, h) * .075f
                    p.color = colors[(n - 1) / 10]
                    c.drawCircle(dcx, dcy, r, p)
                    p.color = Color.WHITE
                    p.textAlign = Paint.Align.CENTER
                    p.textSize = r * .9f
                    p.typeface = Typeface.DEFAULT_BOLD
                    c.drawText(n.toString(), dcx, dcy + r * .32f, p)
                    p.textAlign = Paint.Align.LEFT
                }
                return
            }

            val dur = longArrayOf(0, 1100, 750, 650, 1800, 750)[phase]
            val t = ((System.currentTimeMillis() - phaseAt).toFloat() / dur).coerceIn(0f, 1f)
            val ease = t * t * (3f - 2f * t)
            val r = when (phase) {
                1 -> dr * .16f
                2 -> dr * .18f
                3 -> dr * (.18f + .82f * ease)
                4 -> dr
                else -> dr * (1f - .82f * ease)
            }

            val startX = w * .5f
            val startY = h * .48f
            val row = (current - 1) / 10
            val col = (current - 1) % 10
            val cellW = (board.width() - 24f) / 10f
            val cellH = (board.height() - h * .09f) / 9f
            val targetX = board.left + 12f + col * cellW + cellW * .5f
            val targetY = board.top + h * .065f + row * cellH + cellH * .5f

            val x = when (phase) {
                1, 2 -> dcx
                3 -> dcx + (startX - dcx) * ease
                4 -> startX
                else -> startX + (targetX - startX) * ease
            }
            val y = when (phase) {
                1 -> dcy
                2 -> dcy + (board.top - dcy) * ease
                3 -> board.top + (startY - board.top) * ease
                4 -> startY
                else -> startY + (targetY - startY) * ease
            }

            p.color = colors[(current - 1) / 10]
            c.drawCircle(x, y, r, p)
            p.color = Color.WHITE
            c.drawCircle(x, y, r * .58f, p)
            p.color = Color.BLACK
            p.textAlign = Paint.Align.CENTER
            p.textSize = r * .75f
            p.typeface = Typeface.DEFAULT_BOLD
            c.drawText(current.toString(), x, y + r * .25f, p)
            p.textAlign = Paint.Align.LEFT

            if (phase == 4) {
                p.color = Color.WHITE
                p.textSize = h * .05f
                p.textAlign = Paint.Align.CENTER
                c.drawText(numberWords(current), w * .5f, h * .48f + r + h * .06f, p)
                p.textAlign = Paint.Align.LEFT
            }
        }

        private fun numberWords(n: Int): String {
            val u = arrayOf("cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve")
            val teens = arrayOf("diez", "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve")
            val twenties = arrayOf("veinte", "veintiuno", "veintidós", "veintitrés", "veinticuatro", "veinticinco", "veintiséis", "veintisiete", "veintiocho", "veintinueve")
            val tens = arrayOf("", "", "", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa")

            return when {
                n < 10 -> u[n]
                n < 20 -> teens[n - 10]
                n < 30 -> twenties[n - 20]
                n % 10 == 0 -> tens[n / 10]
                else -> tens[n / 10] + " y " + u[n % 10]
            }.replaceFirstChar { it.uppercase() }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action != MotionEvent.ACTION_UP) return true
            val x = e.x
            val y = e.y

            buttons.forEachIndexed { i, pair ->
                if (pair.first.contains(x, y)) {
                    when (i) {
                        0 -> this@MainActivity.showSetup(false)
                        1 -> this@MainActivity.showPlayersDialog()
                        2 -> this@MainActivity.confirmNewGame()
                        3 -> startDraw()
                        4 -> doLine()
                        5 -> this@MainActivity.showSimpleDialog("Fin de Sesión", sessionReport())
                        6 -> this@MainActivity.showSimpleDialog(
                            "Cartones",
                            "La gestión de cartones está pendiente de incorporar."
                        )
                        7 -> pauseGame()
                        8 -> this@MainActivity.showSimpleDialog("Estadísticas", statisticsReport())
                        9 -> doBingo()
                    }
                    return true
                }
            }
            return true
        }
    }
}
