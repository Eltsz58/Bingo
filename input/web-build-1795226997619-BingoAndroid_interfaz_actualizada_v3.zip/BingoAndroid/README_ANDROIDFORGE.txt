BINGO CASINO - PROYECTO ANDROID

Proyecto Android nativo con Kotlin.
Paquete: es.bingo.casino
Orientación: horizontal.
SDK mínimo: Android 7.0 (API 24).
Compilación: JDK 17, Android Gradle Plugin 8.2.2, Kotlin 1.9.22.

CAMBIOS DE ESTA VERSIÓN DE INTERFAZ
- Se conserva el tablero original de 10 columnas x 9 filas y sus proporciones.
- Se elimina el texto "TABLERO · 90 BOLAS".
- Se conserva el panel del bombo con sus dimensiones y elementos originales.
- El título y ambos paneles suben en pantalla.
- La información de partida queda abajo a la izquierda.
- Los diez botones se disponen en dos filas de cinco con efecto 3D.

NOTAS DE FUNCIONALIDAD
- Inicio Sesión abre el diálogo de configuración existente.
- Jugadores permite editar los nombres.
- Nueva partida reinicia tras confirmar y configurar.
- Sacar bola, Cantar Línea, Parada y Cantar Bingo usan la lógica actual.
- Fin de Sesión muestra un resumen; no cierra ni borra la sesión.
- Estadísticas muestra las cifras de la partida.
- Cartones es un botón provisional: la gestión de cartones no existe aún en el código recibido.

COMPILACIÓN
Desde la raíz del proyecto:
    gradle assembleDebug

APK esperado:
    app/build/outputs/apk/debug/app-debug.apk

Este ZIP contiene el proyecto fuente; no incluye un APK precompilado.


ACTUALIZACIÓN DE INTERFAZ (V2)
- Título subido.
- Tablero y bombo desplazados hacia el límite superior.
- Se mantienen las dimensiones exteriores originales de ambos paneles.
- La cuadrícula aprovecha el espacio liberado al retirar el rótulo del tablero.
- Botones más altos, con mayor separación entre filas y tipografía ampliada.
- Información inferior en dos columnas y tres filas, con ajuste automático de texto.
