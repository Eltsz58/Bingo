# Bingo Casino para Android

Primera versión del proyecto nativo Android, portada desde `Bingo(1).vb`.

## Compatibilidad
- `minSdk 24` (Android 7.0 Nougat).
- Interfaz forzada en horizontal.
- Sin dependencias de bibliotecas externas en tiempo de ejecución.
- Proyecto Kotlin + Android Views/Canvas; no utiliza Windows Forms ni GDI+.

## Funciones trasladadas
- Extracción aleatoria de 90 bolas sin repetición.
- Secuencia animada de extracción y presentación.
- Tablero 9 x 10 con bolas extraídas resaltadas.
- Últimas cinco bolas, recaudación y premios.
- Pausa/continuación, cantar línea, cantar bingo y reiniciar.
- Configuración de recaudación y lista de jugadores.
- Reparto 20 % línea / 80 % bingo y registro de ganador e importe entregado.

## Compilación
Abrir esta carpeta con Android Studio (JDK 17 y Android SDK Platform 34) y ejecutar **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
El APK de depuración quedará normalmente en `app/build/outputs/apk/debug/app-debug.apk`.

## Nota de desarrollo
Esta es una primera portabilidad funcional de la lógica y una interfaz moderna inicial. Requiere compilación y prueba en dispositivo real; no se declara todavía como versión validada para distribución. En particular, se recomienda probar tamaños de texto, animación y diálogos en un Galaxy S7 y ajustar detalles visuales tras esa prueba.
