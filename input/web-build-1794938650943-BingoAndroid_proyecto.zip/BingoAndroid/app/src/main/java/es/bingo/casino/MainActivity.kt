package es.bingo.casino

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.*
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var game: BingoView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        game = BingoView()
        setContentView(game)
        game.post { showSetup(false) }
    }

    private fun showSetup(restarting: Boolean) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 8) }
        val money = EditText(this).apply { hint = "Recaudación (€)"; inputType = 8194; setText(game.collection.toString()) }
        val names = EditText(this).apply { hint = "Jugadores (un nombre por línea)"; minLines = 4; gravity = android.view.Gravity.TOP; setText(game.players.joinToString("\n")) }
        box.addView(money); box.addView(names)
        AlertDialog.Builder(this).setTitle("Configuración de la jugada").setView(box)
            .setPositiveButton("Comenzar") { _, _ ->
                game.collection = money.text.toString().replace(',', '.').toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
                game.players = names.text.lines().map { it.trim() }.filter { it.isNotEmpty() }
                if (restarting) game.reset()
                game.invalidate()
            }.setCancelable(false).show()
    }

    private fun prizeDialog(line: Boolean) {
        val amount = if (line) game.linePrize else game.bingoPrize
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 12, 40, 0) }
        val winner = EditText(this).apply { hint = "Nombre del ganador" }
        if (game.players.isNotEmpty()) winner.setText(game.players.first())
        val paid = EditText(this).apply { hint = "Premio entregado (€)"; inputType = 8194; setText(String.format(Locale.US, "%.2f", amount)) }
        box.addView(winner); box.addView(paid)
        AlertDialog.Builder(this).setTitle(if (line) "¡LÍNEA!" else "¡BINGO!").setView(box)
            .setNegativeButton("Cancelar", null).setPositiveButton("Aceptar") { _, _ ->
                val name = winner.text.toString().trim()
                if (name.isNotEmpty()) {
                    if (line) { game.lineDone = true; game.lineWinner = name; game.linePaid = paid.text.toString().replace(',', '.').toDoubleOrNull() ?: amount }
                    else { game.bingoDone = true; game.bingoWinner = name; game.bingoPaid = paid.text.toString().replace(',', '.').toDoubleOrNull() ?: amount }
                    game.invalidate()
                    if (!line) AlertDialog.Builder(this).setTitle("Fin de partida").setMessage(game.summary()).setPositiveButton("Aceptar", null).show()
                }
            }.show()
    }

    inner class BingoView : View(this) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rand = Random(System.nanoTime())
        private val bag = (1..90).toMutableList()
        private val drawn = mutableListOf<Int>()
        private val marked = BooleanArray(91)
        var collection = 100.0
        var players = listOf<String>()
        var lineDone = false; var bingoDone = false
        var lineWinner = ""; var bingoWinner = ""
        var linePaid = 0.0; var bingoPaid = 0.0
        var paused = false
        private var current = 0
        private var phase = 0 // idle, mix, fall, zoom, hold, fly
        private var phaseAt = 0L
        private var lastDrawn = 0
        private var lastDrawAt = 0L
        private var scale = 1f; private var ox = 0f; private var oy = 0f
        private var board = RectF(); private var ballCenter = PointF()
        private val gold = Color.rgb(222, 180, 83)
        private val bg = Color.rgb(10, 13, 25)
        private val colors = intArrayOf(0xffd62828.toInt(),0xfff08c1e.toInt(),0xffe6c31e.toInt(),0xff3caa46.toInt(),0xff1ea0a5.toInt(),0xff326ee0.toInt(),0xff8246be.toInt(),0xffe15aa0.toInt(),0xff82705f.toInt())
        val linePrize get() = round(collection * .20 * 100) / 100
        val bingoPrize get() = collection - linePrize
        private val buttons = mutableListOf<Pair<RectF,String>>()

        fun reset() {
            bag.clear(); bag.addAll(1..90); drawn.clear(); for (i in marked.indices) marked[i] = false
            phase = 0; paused = false; lineDone = false; bingoDone = false; lineWinner = ""; bingoWinner = ""; linePaid = 0.0; bingoPaid = 0.0; current = 0; lastDrawn = 0
            invalidate()
        }
        fun summary(): String = (if (lineDone) "LÍNEA: $lineWinner (${money(linePaid)})\n" else "") + "BINGO: $bingoWinner (${money(bingoPaid)})\nBolas sacadas: ${drawn.size}"
        private fun money(v: Double) = NumberFormat.getCurrencyInstance(Locale("es", "ES")).format(v)
        private fun startDraw() { if (phase != 0 || paused || bingoDone || bag.isEmpty()) return; current = bag.removeAt(rand.nextInt(bag.size)); phase = 1; phaseAt = System.currentTimeMillis(); invalidate() }
        private fun pauseGame() { if (phase == 0 && !bingoDone) paused = !paused; invalidate() }
        private fun doLine() { if (phase == 0 && drawn.isNotEmpty() && !lineDone && !bingoDone) prizeDialog(true) }
        private fun doBingo() { if (phase == 0 && drawn.isNotEmpty() && !bingoDone) prizeDialog(false) }
        private fun buttonsLayout(w: Float, h: Float) {
            buttons.clear(); val gap = w * .012f; val bw = (w - gap * 6) / 5f; val bh = h * .105f; val y = h - bh - h*.025f
            val labels = listOf("SACAR BOLA", if (paused) "CONTINUAR" else "PARADA", "CANTAR LÍNEA", "CANTAR BINGO", "REINICIAR")
            for (i in labels.indices) { val x = gap + i * (bw + gap); buttons.add(RectF(x,y,x+bw,y+bh) to labels[i]) }
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat(); if (w <= 0 || h <= 0) return
            canvas.drawColor(bg)
            val grad = LinearGradient(0f,0f,w,h, intArrayOf(0xff11172b.toInt(),0xff25213b.toInt(),0xff0c1020.toInt()),null,Shader.TileMode.CLAMP)
            p.shader = grad; canvas.drawRect(0f,0f,w,h,p); p.shader = null
            p.color = gold; p.textSize = h*.045f; p.typeface = Typeface.create("sans-serif",Typeface.BOLD); canvas.drawText("BINGO  •  CASINO",w*.025f,h*.065f,p)
            val left = w*.025f; val top = h*.12f; val gap = w*.006f
            val boardW = w*.60f; val boardH = h*.66f; board = RectF(left,top,left+boardW,top+boardH)
            p.color = 0xff171d31.toInt(); canvas.drawRoundRect(board,18f,18f,p)
            p.color = gold; p.textSize = h*.035f; canvas.drawText("TABLERO · 90 BOLAS",board.left+12,board.top+h*.045f,p)
            val cellW = (boardW-24)/10f; val cellH = (boardH-h*.09f)/9f
            p.textAlign = Paint.Align.CENTER; p.textSize = min(cellW*.42f,cellH*.55f); p.typeface = Typeface.create("sans-serif",Typeface.BOLD)
            for (n in 1..90) {
                val row=(n-1)/10; val col=(n-1)%10; val x=board.left+12+col*cellW; val y=board.top+h*.065f+row*cellH
                val r=RectF(x+2,y+2,x+cellW-2,y+cellH-2)
                p.color = if (marked[n]) colors[row] else 0xff252d46.toInt(); canvas.drawRoundRect(r,8f,8f,p)
                p.color = if (marked[n]) Color.WHITE else 0xffaab2c9.toInt(); canvas.drawText(n.toString(),r.centerX(),r.centerY()+p.textSize*.34f,p)
                if (n==lastDrawn && System.currentTimeMillis()-lastDrawAt<3500) { p.style=Paint.Style.STROKE; p.strokeWidth=3f; p.color=gold; canvas.drawRoundRect(r,8f,8f,p); p.style=Paint.Style.FILL }
            }
            p.textAlign=Paint.Align.LEFT
            val sideX=w*.66f; val sideW=w*.315f
            p.color=0xff202943.toInt(); canvas.drawRoundRect(RectF(sideX,top,sideX+sideW,top+boardH),20f,20f,p)
            p.color=gold; p.textSize=h*.035f; canvas.drawText("BOMBO",sideX+18,top+h*.05f,p)
            val cx=sideX+sideW*.5f; val cy=top+boardH*.38f; val radius=min(sideW*.32f,boardH*.25f)
            p.shader=RadialGradient(cx-radius*.3f,cy-radius*.35f,radius,floatArrayOf(0xff6e819e.toInt(),0xff263b5e.toInt(),0xff101a31.toInt()),null,Shader.TileMode.CLAMP)
            canvas.drawCircle(cx,cy,radius,p); p.shader=null
            p.style=Paint.Style.STROKE; p.strokeWidth=5f; p.color=gold; canvas.drawCircle(cx,cy,radius,p); p.style=Paint.Style.FILL
            // Decorative balls in drum
            for (i in 0 until min(24,bag.size)) { val a=i*2.399; val rr=radius*.76f*sqrt((i+1f)/24f); p.color=colors[i%9]; canvas.drawCircle(cx+cos(a).toFloat()*rr,cy+sin(a).toFloat()*rr, max(5f,radius*.075f),p) }
            p.color=Color.WHITE; p.textAlign=Paint.Align.CENTER; p.textSize=h*.027f; canvas.drawText("Quedan ${bag.size} bolas",cx,cy+radius+h*.045f,p)
            p.textAlign=Paint.Align.LEFT; p.color=gold; p.textSize=h*.03f; canvas.drawText("ÚLTIMAS BOLAS",sideX+18,top+boardH*.76f,p)
            val recent=drawn.takeLast(6).asReversed(); for (i in recent.indices) { val rr=h*.035f; val bx=sideX+rr+18+i*(rr*2.25f); val by=top+boardH*.86f; p.color=colors[(recent[i]-1)/10]; canvas.drawCircle(bx,by,rr,p); p.color=Color.WHITE; p.textAlign=Paint.Align.CENTER; p.textSize=rr*.85f; canvas.drawText(recent[i].toString(),bx,by+rr*.3f,p) }
            p.textAlign=Paint.Align.LEFT
            drawAnimatedBall(canvas,w,h,cx,cy,radius)
            p.color=0xffe5e9f2.toInt(); p.textSize=h*.022f
            canvas.drawText("${drawn.size}/90 extraídas  ·  Recaudación ${money(collection)}",w*.025f,h*.825f,p)
            canvas.drawText("Línea 20 %: ${money(linePrize)}   Bingo 80 %: ${money(bingoPrize)}",w*.025f,h*.865f,p)
            canvas.drawText("Línea: ${if(lineDone) lineWinner+" · "+money(linePaid) else "pendiente"}   |   Bingo: ${if(bingoDone) bingoWinner+" · "+money(bingoPaid) else "pendiente"}",w*.025f,h*.905f,p)
            buttonsLayout(w,h); buttons.forEachIndexed { i, pair -> val r=pair.first; val active=when(i){0->phase==0&&!paused&&!bingoDone&&bag.isNotEmpty();1->phase==0&&!bingoDone;2->phase==0&&drawn.isNotEmpty()&&!lineDone&&!bingoDone;3->phase==0&&drawn.isNotEmpty()&&!bingoDone;else->true}; p.color=if(active) intArrayOf(0xffb88a36.toInt(),0xff72572b.toInt(),0xff8d6b30.toInt(),0xff8d6b30.toInt(),0xff573b3b.toInt())[i] else 0xff34394a.toInt(); canvas.drawRoundRect(r,14f,14f,p); p.color=if(active) Color.WHITE else 0xff858b9b.toInt(); p.textAlign=Paint.Align.CENTER; p.textSize=h*.023f; p.typeface=Typeface.create("sans-serif",Typeface.BOLD); canvas.drawText(pair.second,r.centerX(),r.centerY()+p.textSize*.35f,p) }
            p.textAlign=Paint.Align.LEFT
            if (phase!=0) { val elapsed=System.currentTimeMillis()-phaseAt; val duration=longArrayOf(0,1100,750,650,1800,750)[phase]; if(elapsed>=duration){ if(phase==5){ drawn.add(current); marked[current]=true; lastDrawn=current; lastDrawAt=System.currentTimeMillis(); phase=0 } else { phase++; phaseAt=System.currentTimeMillis() } }; postInvalidateDelayed(16) }
            else if (!paused && !bingoDone) postInvalidateDelayed(500)
            if (paused) { p.color=gold; p.textSize=h*.07f; p.textAlign=Paint.Align.CENTER; canvas.drawText("PARTIDA EN PAUSA",w*.5f,h*.5f,p); p.textAlign=Paint.Align.LEFT }
        }
        private fun drawAnimatedBall(c:Canvas,w:Float,h:Float,dcx:Float,dcy:Float,dr:Float) {
            if(phase==0) { if(drawn.isNotEmpty()){ val n=drawn.last(); val r=min(w,h)*.075f; p.color=colors[(n-1)/10]; c.drawCircle(dcx,dcy,r,p); p.color=Color.WHITE; p.textAlign=Paint.Align.CENTER; p.textSize=r*.9f; p.typeface=Typeface.DEFAULT_BOLD; c.drawText(n.toString(),dcx,dcy+r*.32f,p); p.textAlign=Paint.Align.LEFT }; return }
            val dur=longArrayOf(0,1100,750,650,1800,750)[phase]; val t=((System.currentTimeMillis()-phaseAt).toFloat()/dur).coerceIn(0f,1f); val ease=t*t*(3-2*t)
            val r=when(phase){1->dr*.16f;2->dr*.18f;3->dr*(.18f+.82f*ease);4->dr;else->dr*(1f-.82f*ease)}
            val startX=w*.5f; val startY=h*.48f
            val row=(current-1)/10; val col=(current-1)%10
            val cellW=(board.width()-24f)/10f; val cellH=(board.height()-h*.09f)/9f
            val targetX=board.left+12f+col*cellW+cellW*.5f
            val targetY=board.top+h*.065f+row*cellH+cellH*.5f
            val x=when(phase){1,2->dcx;3->dcx+(startX-dcx)*ease;4->startX;else->startX+(targetX-startX)*ease}
            val y=when(phase){1->dcy;2->dcy+(board.top-dcy)*ease;3->board.top+(startY-board.top)*ease;4->startY;else->startY+(targetY-startY)*ease}
            p.color=colors[(current-1)/10]; c.drawCircle(x,y,r,p); p.color=Color.WHITE; c.drawCircle(x,y,r*.58f,p); p.color=Color.BLACK; p.textAlign=Paint.Align.CENTER; p.textSize=r*.75f; p.typeface=Typeface.DEFAULT_BOLD; c.drawText(current.toString(),x,y+r*.25f,p); p.textAlign=Paint.Align.LEFT
            if(phase==4){p.color=Color.WHITE;p.textSize=h*.05f;p.textAlign=Paint.Align.CENTER;c.drawText(numberWords(current),w*.5f,h*.48f+r+h*.06f,p);p.textAlign=Paint.Align.LEFT}
        }
        private fun numberWords(n:Int):String { val u=arrayOf("cero","uno","dos","tres","cuatro","cinco","seis","siete","ocho","nueve"); val teens=arrayOf("diez","once","doce","trece","catorce","quince","dieciséis","diecisiete","dieciocho","diecinueve"); val twenties=arrayOf("veinte","veintiuno","veintidós","veintitrés","veinticuatro","veinticinco","veintiséis","veintisiete","veintiocho","veintinueve"); val tens=arrayOf("","","","treinta","cuarenta","cincuenta","sesenta","setenta","ochenta","noventa"); return when { n<10->u[n]; n<20->teens[n-10]; n<30->twenties[n-20]; n%10==0->tens[n/10]; else->tens[n/10]+" y "+u[n%10] }.replaceFirstChar { it.uppercase() } }
        override fun onTouchEvent(e: MotionEvent): Boolean { if(e.action!=MotionEvent.ACTION_UP)return true; val x=e.x;val y=e.y; buttons.forEachIndexed { i,pair->if(pair.first.contains(x,y)){when(i){0->startDraw();1->pauseGame();2->doLine();3->doBingo();4->AlertDialog.Builder(this@MainActivity).setTitle("Reiniciar partida").setMessage("Se borrarán las bolas extraídas y los premios anotados. ¿Continuar?").setNegativeButton("Cancelar",null).setPositiveButton("Reiniciar"){_,_->reset();showSetup(true)}.show()};return true} };return true }
    }
}
